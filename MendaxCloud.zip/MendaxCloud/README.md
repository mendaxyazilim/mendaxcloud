# MendaxCloud

MendaxCloud build in Ruby. It makes bypass in CloudFlare for discover real IP.
This can be useful if you need test your server and website. Testing your protection against Ddos (Denial of Service) or Dos.
CloudFlare is services and distributed domain name server services, sitting between the visitor and the Cloudflare user's hosting provider, acting as a reverse proxy for websites. 
Your network protects, speeds up and improves availability for a website or the mobile application with a DNS change. 

Version: 2.1

<em>Use:</em>
<strong>ruby hatcloud.rb -h or --help </strong><br />
<strong>ruby hatcloud.rb -b your site </strong> <br />
or<br />
<strong>ruby hatcloud.rb --byp your site </strong><br />



<em>Uso: </em>
<strong>ruby hatcloud.rb -b seu site </strong><br />
ou<br />
<strong>ruby hatcloud.rb --byp seu site</strong><br />


